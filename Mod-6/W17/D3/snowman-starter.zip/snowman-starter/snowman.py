


def play_snowman():
    pass

play_snowman()
